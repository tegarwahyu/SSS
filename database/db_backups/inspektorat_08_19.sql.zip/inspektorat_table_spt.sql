
-- --------------------------------------------------------

--
-- Table structure for table `spt`
--

DROP TABLE IF EXISTS `spt`;
CREATE TABLE IF NOT EXISTS `spt` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `jenis_spt_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor` int(11) DEFAULT NULL,
  `tgl_mulai` timestamp NOT NULL,
  `tgl_akhir` timestamp NOT NULL,
  `lokasi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approval_status` enum('approved','rejected','processing') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'processing',
  `approval_by` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Approval User ID',
  `notes` text COLLATE utf8mb4_unicode_ci COMMENT 'give note if approval status rejected',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `spt_jenis_spt_id_foreign` (`jenis_spt_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `spt`
--

INSERT INTO `spt` (`id`, `jenis_spt_id`, `name`, `nomor`, `tgl_mulai`, `tgl_akhir`, `lokasi`, `approval_status`, `approval_by`, `notes`, `created_at`, `updated_at`) VALUES
(5, 5, 'Penjemuran Ikan Asin di Sepanjang', 303, '2019-06-03 17:00:00', '2019-06-25 17:00:00', 'Sepanjang Taman Sidoarjo', 'approved', 7, NULL, '2019-06-24 01:26:49', '2019-07-04 07:59:20'),
(2, 7, 'baru', 321, '2019-05-31 17:00:00', '2019-06-14 17:00:00', 'Tanah Abang', 'approved', NULL, NULL, '2019-06-13 00:01:20', '2019-06-27 14:20:05'),
(6, 6, 'Reviu Renstra Tahun 2016-2021', NULL, '2019-07-01 07:00:00', '2019-07-05 07:00:00', 'Kecamatan Sidoarjo Kabupaten Sidoarjo', 'approved', 7, NULL, '2019-06-28 14:11:20', '2019-07-01 15:30:34'),
(7, 5, 'Perencanaan Angaran APBD', NULL, '2019-07-03 07:00:00', '2019-07-05 07:00:00', 'Desa Balongbendo Kecamatan Krian', 'rejected', 7, 'tolak aja', '2019-07-02 08:53:39', '2019-07-02 09:16:44'),
(8, 10, 'test', NULL, '2019-07-05 07:00:00', '2019-07-19 07:00:00', 'Pagerwojo', 'processing', NULL, NULL, '2019-07-02 09:56:25', '2019-07-02 09:56:25'),
(9, 6, '03/07/2019', 201, '2019-07-03 07:00:00', '2019-07-05 07:00:00', 'Dimanapun kau berada', 'approved', 6, NULL, '2019-07-03 09:47:08', '2019-07-04 08:05:27'),
(10, 7, 'perancangan', 531, '2019-07-09 17:00:00', '2019-07-10 17:00:00', 'SDN wonoayu', 'approved', 6, NULL, '2019-07-08 20:31:50', '2019-07-10 18:36:33');
