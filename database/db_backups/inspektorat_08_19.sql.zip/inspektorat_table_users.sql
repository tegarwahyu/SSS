
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jabatan` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pangkat` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `nip`, `jabatan`, `pangkat`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(6, 'Super', 'Admin', 'admin@local.host', 'admin@local.host', '90909090', 'Inspektur Kabupaten', 'I/A', NULL, '$2y$10$5.6Cs4VHw0doRvG6pIPYT.Ygrx2VV7J4nFdHD1U66McsvwL2DTpdO', 'lxbraxMHevwdeoySvdORUtrl97gkwDR8W29uDl4W4G47KjnIhbkAKyl5RXRJ', '2019-06-18 19:32:57', '2019-06-18 19:32:57'),
(2, 'Bag', 'Perencanaan', 'rencana@local.host', '08885656', '', NULL, NULL, NULL, '$2y$10$ie3FCXY1.lE4IcRFFR9pc.JjqyW.JbW5pg9furifvhyKXIdZvpn16', 'T9XAzDyCsizSBwYn7qlpeGuy518Rx1Zj1KYsIF17XfgiwvqY87g75JSKMOei', '2019-06-03 10:11:39', '2019-06-03 10:11:39'),
(3, 'Bag', 'Umum', 'umum@local.host', '856789', '', NULL, NULL, NULL, '$2y$10$RmvHlAsX5zsWQzc/2T80S.f4N.gkrjf58v/xuzoY5ZGJ3Lp9TPi2i', '7M46ZzfUHJvJHXq087uc73z6YAD4nSFSTOFKzkfHdbfRiiT2tl47XijIVY4B', '2019-06-03 10:12:15', '2019-06-03 10:12:15'),
(4, 'Auditor', 'Auditor', 'audit@local.host', '88877888', '', NULL, NULL, NULL, '$2y$10$TgpT8ooFc8SkZ/TMnMinru2mXP1aSzvXs6v4RsYTbywxxDIomaQGO', NULL, '2019-06-03 10:13:02', '2019-06-03 10:13:02'),
(5, 'Tegar', 'WPIP', 'tegar@local.host', '+628567892', NULL, NULL, NULL, NULL, '$2y$10$GI0kjoxWCtpDOGFFX5oy3uVlB.itkdo8tCUP3ordw6D/6uT7mgDnS', NULL, '2019-06-18 01:09:02', '2019-06-18 01:09:02'),
(7, 'User', 'Inspektur', 'inspektur@local.host', '08226767890', '4567890', 'Inspektur Kabupaten', 'I/A', NULL, '$2y$10$6fQsHp1kb7AvrYX7P2HtVe4oe8/L9fBvLH2ghxJBXI0o6ryEUHrA2', 'MxI5wPQZyICn66syKSBunZzoraecg9nqMCIpP2xH4h16SRwflDAf6K0thYaW', '2019-07-01 13:48:31', '2019-07-01 13:48:31'),
(8, 'Auditor', 'Utama', 'utama@local.host', '123123123', '351351', 'Auditor Utama', 'IV/A', NULL, '$2y$10$QwVPABChpEeqLVEhqUu3Du1W7ITkJrx8gTA28XYJoyownUsIpVnD.', 'hx05JRh5O4Bp1GioHoW7HCGtDK8Ed352Bp7ATNwINmQgWenhjX5NVAIdOo67', '2019-07-03 09:03:37', '2019-07-03 09:03:37'),
(9, 'Auditor', 'Madya', 'madya@local.host', '3717171', '5455454545454', 'Auditor Madya', 'III/B', NULL, '$2y$10$gWzZRpx7FgCbVqs77ANui.UcEVgGKR2OiFNeXK4nZi6mmIeR5IAna', NULL, '2019-07-03 09:04:52', '2019-07-03 09:04:52'),
(10, 'Auditor', 'Muda', 'muda@local.host', '08226767890', '3414124124', 'Auditor Muda', 'III/B', NULL, '$2y$10$7bX/nGmRj01UclbcfuezV.J9yftnBvSztnG8R/AtM16ZaFN.pgXuq', NULL, '2019-07-03 09:05:34', '2019-07-03 09:05:34');
