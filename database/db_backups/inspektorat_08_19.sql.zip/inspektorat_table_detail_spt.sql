
-- --------------------------------------------------------

--
-- Table structure for table `detail_spt`
--

DROP TABLE IF EXISTS `detail_spt`;
CREATE TABLE IF NOT EXISTS `detail_spt` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `spt_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `peran` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lama` int(11) DEFAULT NULL,
  `dupak` double(8,2) DEFAULT NULL,
  `file_laporan` varchar(225) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kode` varchar(225) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenis_laporan` varchar(225) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'jenis pelaporan (KKP,NHP,LHP,LHE,BAP,DLL))',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'status berisikan persetujuan ketua, daltu, dalnis, supervisor, dll',
  PRIMARY KEY (`id`),
  KEY `detail_spt_spt_id_foreign` (`spt_id`),
  KEY `detail_spt_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `detail_spt`
--

INSERT INTO `detail_spt` (`id`, `spt_id`, `user_id`, `peran`, `lama`, `dupak`, `file_laporan`, `kode`, `jenis_laporan`, `status`) VALUES
(15, 5, 4, 'Pembantu Penanggung jawab', 2, NULL, NULL, NULL, NULL, NULL),
(22, 6, 5, 'Pembantu Penanggung jawab', 4, NULL, NULL, NULL, NULL, NULL),
(19, 2, 2, 'Pembantu Penanggung jawab', 2, NULL, NULL, NULL, NULL, NULL),
(21, 6, 6, 'Penanggung Jawab', 2, NULL, NULL, NULL, NULL, NULL),
(20, 2, 3, 'Penanggung Jawab', 5, NULL, NULL, NULL, NULL, NULL),
(23, 6, 2, 'Ketua Tim', 4, NULL, NULL, NULL, NULL, NULL),
(24, 6, 4, 'Anggota Tim', 4, NULL, NULL, NULL, NULL, NULL),
(25, 7, 7, 'Penanggung Jawab', 2, NULL, NULL, NULL, NULL, NULL),
(26, 7, 3, 'Supervisor', 2, NULL, NULL, NULL, NULL, NULL),
(42, 9, 4, 'Anggota Tim', 2, 404.00, NULL, NULL, NULL, NULL),
(41, 9, 8, 'Pengendali Mutu', 2, 0.52, NULL, NULL, NULL, NULL),
(40, 9, 9, 'Pengendali Teknis', 2, 0.42, NULL, NULL, NULL, NULL),
(38, 8, 8, 'Pengendali Mutu', 5, 1.30, NULL, NULL, NULL, NULL),
(39, 9, 10, 'Ketua Tim', 2, 0.26, NULL, NULL, NULL, NULL),
(36, 8, 9, 'Ketua Tim', 7, 0.00, NULL, NULL, NULL, NULL),
(43, 10, 7, 'Penanggung Jawab', 1, 404.00, NULL, NULL, NULL, NULL),
(44, 10, 8, 'Pengendali Mutu', 1, 0.26, NULL, NULL, NULL, NULL);
